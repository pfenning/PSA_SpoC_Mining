from fuzzy_system import FuzzySystem

my_system = FuzzySystem(0.03, 0.4, resolution=0.1)

my_system.plot()
