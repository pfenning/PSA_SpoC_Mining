import SpoC_Kontrolle as SpoC

print(SpoC.udp.pretty(SpoC.udp.example()))

